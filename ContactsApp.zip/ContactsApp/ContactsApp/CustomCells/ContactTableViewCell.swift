//
//  ContactTableViewCell.swift
//  ContactsApp
//
//  Created by David Kababyan on 12/08/2018.
//  Copyright © 2018 David Kababyan. All rights reserved.
//

import UIKit

class ContactTableViewCell: UITableViewCell {

    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
    func setupCell(contact: Contact) {
        
        fullNameLabel.text = contact.fullName
        phoneNumberLabel.text = contact.phoneNumber
        
        if contact.avatar != nil {
            avatarImageView.image = contact.avatar
        }
    }

}
