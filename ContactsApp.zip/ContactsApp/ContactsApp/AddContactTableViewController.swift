//
//  AddContactTableViewController.swift
//  ContactsApp
//
//  Created by David Kababyan on 12/08/2018.
//  Copyright © 2018 David Kababyan. All rights reserved.
//

import UIKit

protocol AddContactTableViewControllerDelegate {
    func didCreateContact(contact: Contact)
}

class AddContactTableViewController: UITableViewController {

    @IBOutlet weak var topView: UIView!
    
    @IBOutlet weak var avatarImageView: UIImageView!
    @IBOutlet weak var saveButtonOutlet: UIButton!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var surnameTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var dateOfBirthTextField: UITextField!
    @IBOutlet weak var addressTextView: UITextView!
    
    var delegate: AddContactTableViewControllerDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.tableFooterView = UIView()
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    //MARK: TableViewDelegates
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return ""
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 1 {
            return 20
        }
        
        return 0
    }
    
    //MARK: IBActions
    
    @IBAction func cancelButtonPressed(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    

    @IBAction func saveButtonPressed(_ sender: Any) {
        
        if nameTextField.text != "" && surnameTextField.text != "" && phoneNumberTextField.text != "" {
            
            createNewContact()
        } else {
            //add alert controller
            print("Please insert Name, Surname and phone number")
        }
    }

    //MARK: Saving Contacts
    func createNewContact() {
        
        let newContact = Contact(_name: self.nameTextField.text!, _surname: self.surnameTextField.text!, _phoneNumber: self.phoneNumberTextField.text!)
        
        delegate!.didCreateContact(contact: newContact)
        self.dismiss(animated: true, completion: nil)
    }

add avatar option
    
}
