//
//  ProfileViewController.swift
//  ContactsApp
//
//  Created by David Kababyan on 11/08/2018.
//  Copyright © 2018 David Kababyan. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var phoneNumberLabel: UILabel!
    
    var localContact: Contact!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        updateUI()
    }
    
    
    //MARK: UpdateUI
    func updateUI() {
        
        if localContact != nil {
            self.title = localContact.fullName
            fullNameLabel.text = localContact.fullName
            phoneNumberLabel.text = localContact.phoneNumber
        }
    }


}
